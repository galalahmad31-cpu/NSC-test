-- ============================================================
-- NSC V2 ACCOUNT / ADMIN SCHEMA
-- Safe additions for the new app shell.
-- Does NOT alter patients/visits calculation data.
-- ============================================================

-- 1) Add optional profile display fields + role.
alter table public.profiles
  add column if not exists full_name text,
  add column if not exists specialty text,
  add column if not exists phone text,
  add column if not exists role text not null default 'user';

-- Keep role values predictable.
alter table public.profiles
  drop constraint if exists profiles_role_check;
alter table public.profiles
  add constraint profiles_role_check check (role in ('user','admin'));

-- 2) Helper for admin-only RLS policies.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.profiles
    where id = auth.uid()
      and role = 'admin'
  );
$$;

-- 3) Admins can read all profiles.
alter table public.profiles enable row level security;
drop policy if exists "admins can read all profiles" on public.profiles;
create policy "admins can read all profiles"
on public.profiles
for select
to authenticated
using (public.is_admin());

-- 4) Admins can read all patient records and visits.
alter table public.patients enable row level security;
drop policy if exists "admins can read all patients" on public.patients;
create policy "admins can read all patients"
on public.patients
for select
to authenticated
using (public.is_admin());

alter table public.visits enable row level security;
drop policy if exists "admins can read all visits" on public.visits;
create policy "admins can read all visits"
on public.visits
for select
to authenticated
using (public.is_admin());

-- 5) Optional renewal-request table for the Settings page.
-- The current UI does not require this table to load.
create table if not exists public.subscription_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  requested_months integer not null check (requested_months > 0),
  proof_url text,
  status text not null default 'pending'
    check (status in ('pending','approved','rejected')),
  admin_note text,
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);

alter table public.subscription_requests enable row level security;

drop policy if exists "users can create own subscription requests" on public.subscription_requests;
create policy "users can create own subscription requests"
on public.subscription_requests
for insert
to authenticated
with check (user_id = auth.uid());

drop policy if exists "users can read own subscription requests" on public.subscription_requests;
create policy "users can read own subscription requests"
on public.subscription_requests
for select
to authenticated
using (user_id = auth.uid());

drop policy if exists "admins can read subscription requests" on public.subscription_requests;
create policy "admins can read subscription requests"
on public.subscription_requests
for select
to authenticated
using (public.is_admin());

drop policy if exists "admins can update subscription requests" on public.subscription_requests;
create policy "admins can update subscription requests"
on public.subscription_requests
for update
to authenticated
using (public.is_admin())
with check (public.is_admin());

-- IMPORTANT:
-- Make your own admin account an admin AFTER running the migration.
-- Replace the email with your real administrator email.
-- update public.profiles set role = 'admin' where email = 'YOUR_ADMIN_EMAIL';

-- Security note:
-- Do not create a broad policy allowing ordinary users to update
-- the entire profiles row if that would let them change role='user'
-- to role='admin'. Prefer a restricted profile-update RPC or
-- column-level permissions for full_name/specialty/phone.
