NSC V2 structure

NSC_v2.html = main page + original clinical engine. Do not remove/alter its calculation engine.
protected/css/nsc-shell.css = new application shell/navigation styles.
protected/js/nsc-shell.js = new navigation/dashboard/patient-page shell logic; wraps the existing patient/visit functions.
supabase/NSC_v2_schema.sql = database additions for profiles/admin/subscription requests.

Existing protected/auth.js and Supabase setup remain required.
